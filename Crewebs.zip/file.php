<?php
// variable setting
$name = $REQUEST['name'];
$email = $REQUEST['email'];
$address = $REQUEST['address'];

//check input fields
if (empty($name)||empty($email)||empty($message))
{
  echo "Please fill out all the fields";
}
else
{
  mail("Crewebs@outlook.com", "Apple Signup", $message,"From: $name <$email>");
  echo "<script type='text/javascript>alert('your message sent successfully')
  window.history.log(-1);
  </script>
}
?>